import ControlPanel from './ControlPanel.js'

/* make class ControlPanel available inside the window */
window.ControlPanel = ControlPanel;
