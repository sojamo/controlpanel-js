
/**
  * @classdesc
  */
class Styles {

  /**
    * @constructor
    */
    constructor() {
      this.styles = document.createElement('link');
      this.styles.rel = 'stylesheet';
      this.styles.type = 'text/css';
      this.styles.media = 'screen';
      this.styles.href = 'libraries/assets/styles.css';
      document.getElementsByTagName('head')[0].appendChild(this.styles);
    }

}

export default Styles;
