
/**
  * @classdesc
  */
class Compose {

  /**
    * @constructor
    */
    constructor() {
    }

    init() {
      // this.templates.setTemplateFor(
      //   'slider',
      //   (theId, theParams) => {
      //
      //     /* default Parameters */
      //     const {value=0.5, min=0, max=1, x=0, y=0, r=0, width=100, height=20} = theParams;
      //
      //     /* the View */
      //     this.builder().setElement(
      //       'slider',
      //       (theController, theParams) => {
      //       const {width, height, label, color, min, max, value} = theParams;
      //       const v0 = Common.constrainValue(value, min, max);
      //       const v1 = Common.mapValue(v0, min, max, 0, width);
      //       const v2 = v0.toFixed(2);
      //       updateElementFor(theController, 'bg', createRect, {width, height, class: 'slider bg'});
      //       updateElementFor(theController, 'fg', createRect, {width: v1, height, class: 'slider fg'});
      //       updateElementFor(theController, 'label', createLabel, {x: width+4, y: height/2, 'text-anchor': 'start', class: 'slider label', text: label});
      //       updateElementFor(theController, 'value', createLabel, {x: 4, y: height/2, 'text-anchor': 'start', class: 'slider label', text: v2});
      //       updateElementFor(theController, 'area', createRect, {width, height, class: 'area'});
      //       return theController;
      //     });
      //
      //     /* the Controller */
      //     this.template().getTemplateFor('slider', theId)
      //       .setAttributes(Common.merge({value, min, max, width, height, x, y, r}, theParams))
      //       .addEventFor(Event.wheel, {preventDefault: {}, elementScroll: {min, max, width}})
      //       .addEventFor(Event.mouseDown, {elementDown: {min, max, width}, startDrag: {then: 'elementDrag', min, max, width}})
      //       .addEventFor(Event.mouseEnter, {changeColor: {element: 'fg', to: 'active'}})
      //       .addEventFor(Event.mouseLeave, {changeColor: {element: 'fg', to: 'fg'}})
      //       .setParent(this.root())
      //       .build();
      //
      //     /* 4. finally return the newly created controller */
      //     return controller;
      //   }
      // );

    }
}

export default Changes;
