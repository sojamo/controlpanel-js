import Common from './Common.js'


/**
  * @classdesc
  */
class Builder {

  /**
    * @static
    * @desc returns the svg namespace used in this project
    * @returns {String} svg name space
    */
  static svgns() { return 'http://www.w3.org/2000/svg'; }


  /**
    * @desc initializes the Builder and creates the root element
    * @param {Object} theParams the initial parameters passed on from the ControlPanel
    * @returns {Object} root element
    */
  init(theParams) {
    const defaultAttributes = {
      id: 'cp5',
      class: 'cp5',
      style: {
        top: 20,
        left: 20,
        position: 'absolute',
        background: 'rgba(0,0,0,0.25)'
      }
    };

    const root = setAttributesFor(createElement('svg'), Common.merge(defaultAttributes, theParams));

    setElement('slider', (theController, theParams) => {
      const {width, height, label, color, min, max, value} = theParams;
      const v0 = Common.constrainValue(value, min, max);
      const v1 = Common.mapValue(v0, min, max, 0, width);
      const v2 = v0.toFixed(2);
      const spacing = 4;
      updateElementFor(theController, 'bg', createRect, {width, height, class: 'slider bg'});
      updateElementFor(theController, 'fg', createRect, {width: v1, height, class: 'slider fg'});
      updateElementFor(theController, 'label', createLabel, {x: width + spacing, y: height/2, 'text-anchor': 'start', class: 'slider label', text: label});
      updateElementFor(theController, 'value', createLabel, {x: spacing, y: height/2, 'text-anchor': 'start', class: 'slider label', text: v2});
      updateElementFor(theController, 'area', createRect, {width, height, class: 'area'});
      return theController;
    });

    setElement('button', (theController, theParams) => {
      const {width, height, label, color} = theParams;
      updateElementFor(theController, 'bg', createRect, {width, height, class: 'button bg'});
      updateElementFor(theController, 'label', createLabel, {x: width/2, y: height/2, 'text-anchor': 'middle', class: 'label', text: label});
      updateElementFor(theController, 'area', createRect, {width, height, class: 'area'});
      return theController;
    });

    setElement('switch', (theController, theParams) => {
      const {value, width, height, label, color} = theParams;
      const c0 = value === true ? 'switch bg': 'switch fg';
      updateElementFor(theController, 'bg', createRect, {width, height, class: c0});
      updateElementFor(theController, 'label', createLabel, {x: width+4, y: height/2, 'text-anchor': 'start', class: 'label', text: label});
      updateElementFor(theController, 'area', createRect, {width, height, class: 'area'});
      return theController;
    });

    return root;
  }

}

/**
  * @desc this object contains functions to create a visual representation of a controller
  */
const elements = {};


export const setElement = (theIndex, theFn) => {
  elements[theIndex] = theFn;
}


/**
  * @desc updates or creates a controller's svg element
  * @param {Object} theController  the controller
  * @param {String} theIndex  the index of the svg element
  * @param {Function} theFn  a function that will be called to create an svg element
  * @param {Object} theParams  the svg element's parameters
  */
export const updateElementFor = (theController, theIndex, theFn, theParams) => {
  const {text} = theParams;
  /* first check if the svg element for the given controller exists */
  if(!theController.getElement().hasOwnProperty(theIndex)) {
    /* if it doesn't exist yet, create it by applying theFn and the given parameters */
    theController.getElement()[theIndex] = theFn(theParams);
    theController.getElement().insertBefore(theController.getElement(theIndex), theController.getElement('area'));
  }
  if(text !== undefined) {
  setText(theController.getElement(theIndex), text);
    /* delete text property from theParams, we do not want to add it as an attribute */
    delete theParams.text;
  }

  /* then make changes to the controller's attributes where required */
  setAttributesFor(theController.getElement(theIndex), theParams);

  console.log()
}

/**
  * @desc
  * @param {Object} theElement  svg element
  * @param {Object} theParams  object with attributes
  * @returns {Object} svg element based on type
  */
export const buildElementsFor = (theController, theParams) => {
  const type = theController.type;
  const attributes = Common.merge(theController.getState(), theParams);
  const element = elements[type](theController, attributes);
  return element;
};


/**
  * @desc helper function to set attributes for an svg element
  * @param {Object} theElement  svg element
  * @param {Object} theParams  object with attributes
  * @returns {Object}  svg element with attributes changed
  */
  export const setAttributesFor = (theElement, theParams) => {
    // TODO: transform is a special case here, how should we go about it.
    Object.keys(theParams).forEach(key => {
      theElement.setAttribute(key, Common.isObject(theParams[key]) ? Common.objectToString(theParams[key]):theParams[key]);
    });
    return theElement;
  }


/**
  * @desc helper function to creating svg elements
  * @param {String} theType the svg type
  * @returns {Object} svg element
  */
export const createElement = theType => {
  return document.createElementNS(Builder.svgns(), theType);
}



/**
  * @desc helper to create a svg rectangle
  * @param {Object} theParams  the parameters to be used to style the rectangle
  * @returns {Object} svg rect with attributes added
  */
export const createRect = theParams => {
  const {width=100, height=100, rx=0, ry=0, fill='rgba(255,255,255,0.0)', class:klass} = theParams;
  const defaultAttributes = {fill, width, height, rx, ry};
  const rect = setAttributesFor(createElement('rect'), Common.merge(defaultAttributes, theParams));
  return rect;
}


/**
  * @desc helper to create a svg text element
  * @param {Object} theParams  the parameters to be used to style a text label
  * @returns {Object} svg text with attributes added
  */
export const createLabel = theParams => {
  const {textAnchor, text, class:klass, fill='rgba(255,255,255,0.0)'} = theParams;
  const defaultAttributes = {'alignment-baseline': 'central', 'text-anchor': textAnchor, fill}
  delete theParams.text;
  const label = setAttributesFor(setText(createElement('text'), text), Common.merge(defaultAttributes, theParams));
  return label;
}

export const setText = (theElem, theText) => {
  theElem.innerHTML = theText;
  return theElem;
}

/* TODO implement circle */
export const createCircle = theParams => {}

/* TODO implement chart */
export const createChart = theParams => {
  const chart = createElement('svg');
  const line = createElement('polyline');
  return chart;
}

export default Builder;
