import Common from './Common.js'
import {addEventListener} from './Events.js'
import {createElement, setAttributesFor, buildElementsFor} from './Builder.js'

/**
  * @class
  * @classdesc
  */
class Controller {

  /**
    * @constructor
    * @desc creates a Controller object used to build a controller
    * @param {Object} theId a unique Id
    * @param {Object} theBase a references to the controlpanel
    * @param {String} theType which type of controller will be created
    */
    constructor(theId, theType, theEvents) {
      const [id, type] = [theId, theType];
      this.id = id;
      this.type = type;
      this.events = theEvents;
      this.state = {};

      /* a container for all svg elements belonging to this controller  */
      this.element = setAttributesFor(createElement('g'), {type, id});

      /* an svg element used as overlay to handle mouse and touch input */
      this.element.area = setAttributesFor(createElement('rect'), {fill: 'rgba(0,0,0,0)'});
      this.element.appendChild(this.element.area);
    }

    /**
      * @desc
      * @param {Object} theIndex
      * @returns {Object} an svg element
      */
    getElement(theIndex) {return theIndex === undefined ? this.element:this.element[theIndex];}

    /**
      * @desc
      * @returns {Object} a controller's attributes
      */
    getState() {return this.state;}

    /**
      * @desc
      * @param {Object} theIndex
      * @returns {Object} a specific controller attribute
      */
    getStateFor(theIndex) {return this.getState()[theIndex] || undefined;}


    /**
      * @desc
      * @param {Object} theEvent
      * @returns {Object} an event, see Events.js
      */
    getEvent(theEvent) {return this.events.get(theEvent);}

    /**
      * @desc
      * @param {Object} theParams
      * @returns {Object} self
      */
    setState(theParams) {
      this.state = Common.merge(this.state, theParams);
      return this;
    }

    /**
      * @desc
      * @param {Object} theEvent
      * @param {Object} theParams
      * @returns {Object} self
      */
    addEventFor(theEvent, theParams) {
      Object.keys(theParams).forEach( key => {
        addEventListener(this.getElement('area'), theEvent, (event) => {
          const params = Common.merge({}, theParams[key]);
          params['element'] = params['element'] === undefined ? this.getElement() : this.getElement(params['element']);
          params['event'] =  params['event']  === undefined ? event : this.getEvent(params['event']);
          this.getEvent(key)(this, params);
        });
      });
      return this;
    }

    /**
      * @desc
      * @param {Object} theParent
      * @returns {Object} self
      */
    /* FIXME: make sure we don't allow this to be called more than once to avoid multiple parents */
    setParent(theParent) {
      theParent.appendChild(this.getElement());
      return this;
    }

    /**
      * @desc
      * @returns {Object}
      */
    build() {
      const {width, height, x, y, r} = this.getState();
      setAttributesFor(this.getElement(), {transform: `translate(${x},${y}) rotate(${r})`, width: width, height: height});
      buildElementsFor(this, this.getState());
    }

    print() {
      console.log(this.getElement(), this.getState());
    }

}

export default Controller;
