
/**
  * @classdesc
  */
class Changes {

  /**
    * @constructor
    */
    constructor() {
    }

}

export default Changes;
