import Common from './Common.js'
import AHelper from './AHelper.js'
import {setAttributesFor} from './Builder.js'


/* FIXME: consider to make events globally accessible and const instead of using a class */


/**
  * @classdesc
  */
class Event extends AHelper {

  /**
    * @constructor
    */
  constructor(theBase) {
    super(theBase);
    this.dragTarget = undefined;
    this.isConfigured = false;
    this.events = {};
  }

  /**
    * @desc
    * @param {Object} theRoot
    */
  configure(theRoot) {

    if(this.isConfigured) return;

    /* mouse events */
    addEventListener(document, Event.mouseMove, event => {
      if(this.dragTarget === undefined) return;
      this.dragTarget.params['event'] = event; /* FIXME: is there a better way of adding event to this.dragTarget.params */
      this.apply(this.dragTarget.controller, 'drag', this.dragTarget.params);
    });

    addEventListener(document, Event.mouseUp, event => {
      this.apply(this.dragTarget !== undefined ? this.dragTarget.controller: undefined, 'stopDrag', {event});
    });

    addEventListener(window, Event.resize, event => {
    });

    /* wheel events */
    const wheel = () => {return Event.onWheel in document ? Event.wheel : Event.mouseWheel; };
    addEventListener(theRoot, wheel(), event => {event.preventDefault()});

    /* TODO: touch events, for mobile devices */


    /* setup default events */

    this.set('startDrag', (theController, theParams) => {
      this.dragTarget = {controller: theController, params: theParams};
    });

    this.set('stopDrag', (theController, theParams) => {
      this.dragTarget = undefined; /* FIXME: should not be undefined but an empty controller */
    });

    this.set('drag', (theController, theParams) => {
      const {then} = theParams;
      this.get(then)(theController, theParams);
    });

    this.set('call', (theController, theParams) => {
      const {fn} = theParams;
      fn(theController, theParams);
    });

    this.set('preventDefault', (theController, theParams) => {
      const {event} = theParams;
      event.preventDefault();
    });

    this.set('changeColor', (theController, theParams) => {
      const {element, to, color=this.properties().color} = theParams;
      setAttributesFor(element, {style: {fill: color[to]}});
    });

    this.set('elementDrag', (theController, theParams) => {
      const {event, min, max, width} = theParams;
      const v0 = theController.getState().value + Common.mapValue(event.movementX, 0, width, 0, max-min);
      const value = Common.constrainValue(v0, min, max);
      this.base().change(theController.id, {value});
    });

    this.set('elementDown', (theController, theParams) => {
      const {event, element, min, max, width} = theParams;
      const v0 = Common.mapValue(event.clientX - element.area.getBoundingClientRect().left, 0, width, min, max);
      const value = Common.constrainValue(v0, min, max);
      this.base().change(theController.id, {value});
    });

    this.set('elementScroll', (theController, theParams) => {
      const {event, min, max, width} = theParams;
      const v0 = theController.getState().value + Common.mapValue(event.deltaY, 0, width, 0, max-min);
      const value = Common.constrainValue(v0, min, max);
      this.base().change(theController.id, {value});
    });

    this.isConfigured = true;
  }


  /**
    * @desc
    * @param {Object} theName
    * @param {Object} theFunction
    * @returns {Object} self
    */
  set(theEvent, theFunction) {
    this.events[theEvent] = theFunction;
    return this;
  }

  /**
    * @desc request an event
    * @param {Object} theEvent
    * @returns {Object} an event function from the pool of events or a default function
    */
  get(theEvent) {
    return this.events[theEvent] || (() => { console.log('Event',theEvent, 'does not exist.')});
  }

  /**
    * @desc
    * @param {Object} theController
    * @param {Object} theEvent
    * @param {Object} theParams
    * @returns {Object} self
    */
  apply(theController, theEvent, theParams) {
    this.events[theEvent](theController, theParams);
    return this;
  }

}

/**
  * @desc
  * @param {Object} theElement
  * @param {Object} theType
  * @param {Object} theCallback
  */
export const addEventListener = (theElement, theType, theCallback) => {
  if (theElement.addEventListener) {
    theElement.addEventListener(theType, theCallback, false);
  } else if (theElement.attachEvent) {
    theElement.attachEvent('on' + theType, theCallback);
  }
}

Event.change           = 'change';
Event.click            = 'click';
Event.mouseDown        = 'mousedown';
Event.mouseEnter       = 'mouseenter';
Event.mouseLeave       = 'mouseleave';
Event.mouseMove        = 'mousemove';
Event.mouseUp          = 'mouseup';
Event.mouseWheel       = 'mousewheel';
Event.onWheel          = 'onwheel';
Event.resize           = 'resize';
Event.wheel            = 'wheel';

export default Event;
