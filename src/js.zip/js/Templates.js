import AHelper from './AHelper.js'
import Common from './Common.js'
import Controller from './Controller.js'
import Event from './Events.js'
import {setAttributesFor} from './Builder.js'

/**
  * @classdesc
  */
class Templates extends AHelper {

  /**
    * @constructor
    */
  constructor(theBase) {
    super(theBase);
    this.rootRef = undefined;
    this.templates = {};
  }

  /**
    * @desc
    * @param {Object} theParams
    * @returns {Object} newly created Controller
    */
  create(theId, theParams) {
    const {type} = theParams;
    if(this.templates.hasOwnProperty(type)) return this.templates[type](theId, theParams);
  }


  /**
    * @desc
    * @param {Object} theRoot
    */
  configure(theRoot) {

    this.rootRef = theRoot;

    /**
     * To create a controller template, the following 4 steps are necessary:
     * 1. configure default parameters first
     * 2. create a new controller of a given type
     * 3. set the states and events for the controller
     * 4. return the newly created controller
     */

    this.setTemplateFor('button',
      (theId, theParams) => {
        /* 1. configure default parameters first */
        const {value=1, x=0, y=0, r=0, width=100, height=20} = theParams;

        /* 2. create a new controller of type button */
        const controller = this.createControllerFor(theId, 'button');

        /* 3. now set the state, events, parent for the button */
        controller
          .setState(Common.merge({value, width, height, x, y, r},theParams))
          .addEventFor(Event.click, {call: {fn: () => {console.log('hello click');}}})
          .addEventFor(Event.mouseEnter, {changeColor: {element: 'bg', to: 'fg'}})
          .addEventFor(Event.mouseLeave, {changeColor: {element: 'bg', to: 'bg'}})
          .addEventFor(Event.mouseDown, {changeColor: {element: 'bg', to: 'active'}})
          .addEventFor(Event.mouseUp, {changeColor: {element: 'bg', to: 'fg'}})
          .setParent(this.root())
          .build();

        /* 4. finally return the newly created controller */
        return controller;
      }
    );

    this.setTemplateFor('slider',
      (theId, theParams) => {

        /* 1. configure default parameters first */
        const {value=0.5, min=0, max=1, x=0, y=0, r=0, width=100, height=20} = theParams;

        /* 2. create a new controller of type slider */
        const controller = this.createControllerFor(theId, 'slider');

        /* 3. now set the state for the slider */
        controller
          .setState(Common.merge({value, min, max, width, height, x, y, r}, theParams))
          .addEventFor(Event.wheel, {preventDefault: {}, elementScroll: {min, max, width}})
          .addEventFor(Event.mouseDown, {elementDown: {min, max, width}, startDrag: {then: 'elementDrag', min, max, width}})
          .addEventFor(Event.mouseEnter, {changeColor: {element: 'fg', to: 'active'}})
          .addEventFor(Event.mouseLeave, {changeColor: {element: 'fg', to: 'fg'}})
          .setParent(this.root())
          .build();

        /* 4. finally return the newly created controller */
        return controller;
      }
    );


    this.setTemplateFor('switch',
      (theId, theParams) => {

        /* 1. configure default parameters first */
        const {value=false, x=0, y=0, r=0, width=20, height=20} = theParams;

        /* 2. create a new controller of type slider */
        const controller = this.createControllerFor(theId, 'switch');

        /* 3. now set the state for the slider */
        controller
          .setState(Common.merge({value, width, height, x, y, r}, theParams))
          .addEventFor(Event.click, {call: {fn:() => { this.base().change(theId, {value: !controller.getState().value})}}})
          .setParent(this.root())
          .build();

        /* 4. finally return the newly created controller */
        return controller;
      }
    );
  }

  /**
    * @desc creates a new controller based on type and parameters
    * @param {String} theType the type of controller to be created
    * @returns {Object} root element
    */
  createControllerFor(theId, theType) {
    const controller = new Controller(theId, theType, this.events());
    return controller;
  }

  /**
    * @desc
    * @param {Object} theName
    * @param {Object} theFunction
    * @returns {Object} self
    */
  setTemplateFor(theName, theFunction) {
    this.templates[theName] = theFunction;
    return this;
  }

  /**
    * @desc
    * @returns {Object}
    */
  root() {return this.rootRef;}

}


export default Templates;
