/* ControlPanel */

import Builder            from './Builder.js'
import Changes            from './Changes.js'
import Common             from './Common.js'
import Event              from './Events.js'
import Observer           from './Observer.js'
import Templates          from './Templates.js'
import Styles             from './Styles.js'

import {addEventListener} from './Events.js'
import {setAttributesFor,createElement} from './Builder.js'



/**
  * @classdesc
  */
class ControlPanel {

  /**
    * @constructor
    */
  constructor(theApp, theParams = {width: '400px', height: '300px'}) { // , style: {top: 10, left: 10}
    this.app         = theApp;
    this.builder     = new Builder();
    this.changes     = new Changes(this);
    this.observer    = new Observer(this);
    this.events      = new Event(this);
    this.styles      = new Styles(this);
    this.templates   = new Templates(this);

    this.controllers = {};
    this.properties  = {
      color: {
        bg: 'rgba(0,45,90,1.0)',
        fg: 'rgba(0,116,216,1.0)',
        active: 'rgba(0,170,255,1.0)',
        txt: 'rgba(255,255,255,1.0)'
      }
    };


    /* define the root element */
    const root = this.builder.init(Common.merge(theParams, {}));

    /* initialize the control-panel */
    document.body.appendChild(root);

    /* setup controller-events */
    this.events.configure(root);

    /* setup controller-templates */
    this.templates.configure(root);

    /* The minimize/maximize Icon TODO: where should this go? */
    const minimize = setAttributesFor(
      document.createElementNS('http://www.w3.org/2000/svg', 'circle'),
      {
        style: {
          fill: 'rgba(255,255,255,0.5)'
        },
        cx:12,
        cy:12,
        r:8
      });
    minimize.value = false;

    addEventListener(minimize, Event.click, (ev) => {
      minimize.value = !minimize.value;
      setAttributesFor(root, {width: minimize.value ? 48:300, height: minimize.value ? 24:450});
    });
    root.appendChild(minimize);
  }

  /**
   * @desc
   * @param theId
   * @param theParams
   * @returns ControlPanel
   */
  create(theId, theParams) {
    /* 1. create a new controller */
    this.controllers[theId] = this.templates.create(theId, theParams);
    /* 2. add observer */
    console.log('created controller:', this.controllers[theId]);
    return this;
  }

  /**
   * @desc
   * @param theId
   * @param theParams
   * @returns ControlPanel
   */
  change(theId, theParams) {
    this.controllers[theId].setState(theParams);
    this.controllers[theId].build();
    return this;
  }

  /**
   * @desc
   * @param theId
   * @returns ControlPanel
   */
  remove(theId) {
    console.log("remove", theTarget, "removes theTarget and all children and observers accordingly.");
    return this;
  }

  /**
   * @desc
   * @param theId
   */
  print(theId) {
    this.controllers[theId].print();
  }

}

export default ControlPanel;
