
class AHelper {

  constructor(theBase) {this.baseRef = theBase;}


  /**
    * @desc
    * @returns {Object}
    */
  base() {return this.baseRef;}

  /**
    * @desc
    * @returns {Object}
    */
  builder() {return this.baseRef.builder;}

  /**
    * @desc
    * @returns {Object}
    */
  events() {return this.baseRef.events;}

  /**
    * @desc
    * @returns {Object}
    */
  properties() {return this.baseRef.properties;}

}

export default AHelper;
